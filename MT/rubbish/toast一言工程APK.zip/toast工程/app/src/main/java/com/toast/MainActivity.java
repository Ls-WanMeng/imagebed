package com.toast;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

public class MainActivity extends Activity {
    public static Activity a ;
    
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
       setContentView(R.layout.activity_main);
       text.a1(this);
       show.hthy(this);
       
    }
}

