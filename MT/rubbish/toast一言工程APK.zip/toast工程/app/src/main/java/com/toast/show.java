package com.toast;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class show {
    public static AlertDialog dialog;
    public static void hthy(final Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context,AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        builder.setMessage("加载中..."); 
        builder.setCancelable(true);
// 添加按钮
        builder.setPositiveButton("刷新", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {                   
                      hthy(context);
                      dialog.dismiss();
                }
            });
        
        dialog = builder.show();             
        text.a2();
        
     }

  
}

