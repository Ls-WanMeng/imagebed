package com.toast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.net.ssl.HttpsURLConnection;
import android.view.Gravity;

public final class text {
    static String cachedText;

/*
 *调用处
 */
    public static void a1(Context c) {
        run1 l = new run1(c);
        start(l);
        return;
    }

    public static void a2() {
        run2 l = new run2();
        start(l);
        return;
    }

    public static void a3() {
        run3 l = new run3();
        start(l);
        return;
    }

    public static void a4() {
        run4 l = new run4();
        start(l);
        return;
    }

    public static void a5() {
        run5 l = new run5();
        start(l);
        return;
    }

    /*
     *接口具名
     */

    public static class run1 implements api {
        private Context c;

        public run1(Context c) {
            this.c = c;
        }

        @Override
        public void onLoaded(String t) {
            Toast.makeText(c, t, Toast.LENGTH_SHORT)
            .show();
            
        }
    }

    public static class run2 implements api {
        @Override
        public void onLoaded( String t) {      
            show.dialog.setMessage(t);
            
        }
    }

    public static class run3 implements api {
        @Override
        public void onLoaded(String t) {}
    }

    public static class run4 implements api {
        @Override
        public void onLoaded(String t) {}
    }

    public static class run5 implements api {
        @Override
        public void onLoaded(String t) {}
    }

// 回调接口 抽象类
    public static interface api {
        void onLoaded(String t);
    }

// 异步访问链接

    // 启动方法
    public static void start(final api listener) {
        b quest = new b(listener);
        quest.execute();
    }

    public static class b extends AsyncTask<Void, Void, String> {
        private final api listener;
        private Exception exception;

        public b(api listener) {
            this.listener = listener;
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                // 你的网络请求代码

                URL url = new URL("https://api.sb6.me/hitokoto/api?min_length=1&max_length=30");
                HttpURLConnection connection = (HttpsURLConnection) url.openConnection();
                connection.setConnectTimeout(8000);
                connection.setReadTimeout(8000);
                connection.setRequestMethod("GET");

                InputStream is = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }

                return response.toString();

            } catch (Exception e) {
                exception = e;
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result == null || result.isEmpty()) {
                result = "挽梦遗酒";
            }

            if (listener != null) {
                listener.onLoaded(result);
                
            }
            cachedText=result;
            
        }
    }

}
